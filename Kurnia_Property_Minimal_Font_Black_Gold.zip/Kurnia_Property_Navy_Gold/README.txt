KURNIA PROPERTY — NAVY BLUE / GOLD / WHITE

Isi folder:
- index.html: website utama
- admin.html: halaman login dan pengelolaan logo/portofolio
- assets/: seluruh gambar yang digunakan website

PENTING:
1. Jangan memisahkan index.html dari folder assets.
2. Untuk Netlify, unggah ZIP yang sudah diekstrak atau drag-and-drop seluruh folder hasil ekstrak.
3. Semua tombol WhatsApp membuka nomor 0858-1903-1704 dengan pesan awal:
   Halo Kurnia Property, saya ingin konsultasi...
4. Peta Google Maps menggunakan koordinat -7.929532, 110.467453.
5. Fitur unggah logo dan foto portofolio tersimpan di browser/perangkat yang digunakan (IndexedDB/local browser). Data unggahan tidak otomatis tersinkron ke perangkat lain atau pengunjung website.
6. Halaman admin adalah tampilan awal/front-end. Untuk keamanan login sungguhan dan pengelolaan portofolio lintas perangkat, diperlukan backend/database dan autentikasi server.
