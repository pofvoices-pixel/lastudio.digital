KURNIA PROPERTY — MINIMAL FONT EDITION

Alternatif tipografi dengan font sans-serif minimalis yang konsisten untuk seluruh elemen:
- Heading / judul utama
- Header dan navigasi
- Subheading
- Paragraf dan isi
- Tombol, label, harga, dan footer

Font stack: Inter, Helvetica Neue, Helvetica, Arial.
Warna navy blue, gold, dan white serta isi, foto, Google Maps, WhatsApp CTA, dan struktur admin dipertahankan.

Pemasangan:
1. Ekstrak ZIP.
2. Unggah seluruh folder website ke Netlify.
3. Jangan pisahkan index.html dari folder assets.

Pembaruan navigasi kontak:
- Tombol Hubungi Kami kini tetap tampil di header pada layar HP.
- Tombol WhatsApp mengambang di kanan bawah tampil di desktop dan HP.
- Kedua tombol menggunakan pesan awal WhatsApp yang sama.

EDISI HITAM-EMAS
- Warna dominan navy diganti menjadi hitam/charcoal dengan aksen emas dipertahankan.
- Tipografi minimalis, foto, peta Google Maps, halaman admin, dan struktur situs dipertahankan.
- Tombol Hubungi Kami pada header mobile dan tombol WhatsApp mengambang tetap tersedia.
- Badge Powered by Netlify disembunyikan melalui CSS .netlify-badge.
- Untuk deploy, ekstrak ZIP lalu unggah seluruh folder situs ke Netlify.
